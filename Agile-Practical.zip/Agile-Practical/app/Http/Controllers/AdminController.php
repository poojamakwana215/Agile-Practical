<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\AdminUser;
use App\Model\ApplicationUser;
use Auth;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $users = ApplicationUser::all(); 
        return view('list',compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('login');
    }

    public function checklogin(Request $request)
    {
        $this->validate($request, [
            'username'=>'required',  
            'password'=>'required'
        ]);

        $user_data = array(
	      'username'  => $request->get('username'),
	      'password' => $request->get('password')
	    );

	    if(Auth::attempt($user_data))
	     {
	      return redirect('admin/list');
	     }
	     else
	     {
	      return back()->with('error', 'Wrong Login Details');
	     }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $user=ApplicationUser::where('userid',$id)->first(); 
     	return view('application', compact('user')); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //
        $this->validate($request, [
            'name'=>'required',  
            'email' => 'required|email',
            'address'=>'required',  
            'gender'=>'required',  
            'contact'=>'required|regex:/(01)[0-9]{9}/'  
        ]);

        $user = DB::table('user')
            ->where('userid', $request->get('userid'))
            ->update([
            	'name' => $request->get('name'),
            	'email' => $request->get('email'),
            	'address' => $request->get('address'),
            	'gender' => $request->get('gender'),
            	'contact' => $request->get('contact')
        ]);
        return redirect('admin/list');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $user=ApplicationUser::where('userid',$id)->delete();
        return redirect('admin/list');
    }
}
