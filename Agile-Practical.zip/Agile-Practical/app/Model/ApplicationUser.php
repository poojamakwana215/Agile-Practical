<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ApplicationUser extends Model
{
    //
     protected $table='user';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable=['name','email','address','gender','contact'];
    // protected $fillable=['name','email','address','gender','contact','edication','languages','experience','location','expected_ctc','current_ctc','notice_period'];
}
