<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;

class AdminUser extends Model implements AuthenticatableContract
{
    //
    use Authenticatable;
    public $table = "adminuser";

    public function getAuthPassword()
    {
        return $this->password;
    }
}
