<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\ApplicationController;

Route::get('/','ApplicationController@create');
Route::post('create','ApplicationController@store')->name('create');

Route::group(['prefix' => 'admin'], function () {
    Route::get('/','AdminController@create');
    Route::post('checklogin','AdminController@checklogin')->name('checklogin');
    Route::get('list','AdminController@index')->name('list');
    Route::post('destroy/{id}','AdminController@destroy')->name('destroy');
    Route::post('edit/{id}','AdminController@edit')->name('edit');
    Route::get('application','ApplicationController@create')->name('application');
    Route::post('update','AdminController@update')->name('update');
});
