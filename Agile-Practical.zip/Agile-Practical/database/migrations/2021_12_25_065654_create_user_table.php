<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user', function (Blueprint $table) {
            $table->bigIncrements('userid');
            $table->string('name');
            $table->string('email');
            $table->text('address');
            $table->string('gender');
            $table->string('contact');
            $table->string('education');
            $table->string('languages');
            $table->string('experience');
            $table->string('location');
            $table->string('expected_ctc');
            $table->string('current_ctc');
            $table->string('notice_period');
            $table->timestamps();  
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user');
    }
}
