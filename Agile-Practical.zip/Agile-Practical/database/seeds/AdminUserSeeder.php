<?php

use Illuminate\Database\Seeder;
use App\Model\AdminUser;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        AdminUser::create([
            'id' => '1',
            'username' => 'Admin',
            'password' => Hash::make('123456')
        ]);
    }
}
