<?php $__env->startSection('content'); ?>
<table border="1px">  
<thead>  
<tr>  
<td>  
ID </td>  
<td>  
Name </td>  
<td>  
Email </td>  
<td>  
Gender </td>  
<td>  
Address </td>  
<td>Contact</td>
</tr>  
</thead>  
<tbody>  
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <tr border="none">  
            <td><?php echo e($user->userid); ?></td>  
            <td><?php echo e($user->name); ?></td>  
            <td><?php echo e($user->email); ?></td>  
            <td><?php echo e($user->address); ?></td>  
            <td><?php echo e($user->gender); ?></td>  
            <td><?php echo e($user->contact); ?></td> 
            <td>
            <form action="<?php echo e(url('admin/destroy').'/'.$user->userid); ?>" method="POST">  
                  <?php echo e(csrf_field()); ?> 
                  <button class="btn btn-danger" type="submit">Delete</button>  
                </form>  
               </td>
             <td>
             	<form action="<?php echo e(url('admin/edit').'/'.$user->userid); ?>" method="POST">  
                  <?php echo e(csrf_field()); ?>

                  <button class="btn btn-danger" type="submit">Edit</button>  
                </form>  
</td>  
             </td>
</td>
         </tr>  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
</tbody>  
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>