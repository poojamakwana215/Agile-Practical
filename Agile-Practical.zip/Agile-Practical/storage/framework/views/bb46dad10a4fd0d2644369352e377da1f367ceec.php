<?php $__env->startSection('content'); ?>
<?php if(count($errors) > 0): ?>
   <div class = "alert alert-danger">
      <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </div>
<?php endif; ?>
<?php if(isset($user)): ?>
<form action = "<?php echo e(route('update')); ?>" method = "post" class="mt-4">
<input type="hidden" class="form-control" name="userid" value="<?php echo e($user->userid); ?>" />
<?php else: ?>
<form action = "<?php echo e(route('create')); ?>" method = "post" class="mt-4">
<?php endif; ?>
	<?php echo e(csrf_field()); ?>

	<div class="form-group">
		<label for="name">Name:</label>
		<input type="text" class="form-control" name="name" value="<?php echo e(isset($user) ? $user->name : ''); ?>" />
	</div>
	<div class="form-group">      
		<label for="email">Email:</label>
        <input type="text" class="form-control" name="email" value="<?php echo e(isset($user) ? $user->email : ''); ?>" />
    </div>
    <div class="form-group">      
		<label for="address">Address:</label>
        <textarea class="form-control" name="address"><?php echo e(isset($user) ? $user->address : ''); ?></textarea>
    </div>
    <div class="form-group">      
		<label for="gender">Gender:</label>
        <select name="gender">
        	<option value="">-- Select --</option>
        	<option value="M" <?php echo e($user->gender == 'M'  ? 'selected' : ''); ?>>Male</option>
        	<option value="F" <?php echo e($user->gender == 'F'  ? 'selected' : ''); ?>>Female</option>
        </select>
    </div>
    <div class="form-group">      
		<label for="contact">Contact:</label>
        <input type="phone" class="form-control" name="contact" value="<?php echo e(isset($user) ? $user->contact : ''); ?>" />
    </div>
    <?php if(isset($user)): ?>
    	<button type="submit" class="btn btn-success">Update</button>  
    <?php else: ?>
    	<button type="submit" class="btn btn-success">Submit</button>  
    <?php endif; ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>