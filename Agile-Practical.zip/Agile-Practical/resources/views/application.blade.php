@extends('layout.master')
@section('content')
@if (count($errors) > 0)
   <div class = "alert alert-danger">
      <ul>
         @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
         @endforeach
      </ul>
   </div>
@endif
@if(isset($user))
<form action = "{{ url('update') }}" method = "post" class="mt-4">
<input type="hidden" class="form-control" name="userid" value="{{ $user->userid }}" />
@else
<form action = "{{ route('create') }}" method = "post" class="mt-4">
@endif
	{{ csrf_field() }}
	<div class="form-group">
		<label for="name">Name:</label>
		<input type="text" class="form-control" name="name" value="{{ isset($user) ? $user->name : '' }}" />
	</div>
	<div class="form-group">      
		<label for="email">Email:</label>
        <input type="text" class="form-control" name="email" value="{{ isset($user) ? $user->email : '' }}" />
    </div>
    <div class="form-group">      
		<label for="address">Address:</label>
        <textarea class="form-control" name="address">{{ isset($user) ? $user->address : '' }}</textarea>
    </div>
    <div class="form-group">      
		<label for="gender">Gender:</label>
        <select name="gender">
        	<option value="">-- Select --</option>
        	<option value="M" {{$user->gender == 'M'  ? 'selected' : ''}}>Male</option>
        	<option value="F" {{$user->gender == 'F'  ? 'selected' : ''}}>Female</option>
        </select>
    </div>
    <div class="form-group">      
		<label for="contact">Contact:</label>
        <input type="phone" class="form-control" name="contact" value="{{ isset($user) ? $user->contact : '' }}" />
    </div>
    @if(isset($user))
    	<button type="submit" class="btn btn-success">Update</button>  
    @else
    	<button type="submit" class="btn btn-success">Submit</button>  
    @endif
</form>
@endsection