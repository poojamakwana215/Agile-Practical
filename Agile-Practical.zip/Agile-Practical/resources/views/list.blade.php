@extends('layout.master')
@section('content')
<table border="1px">  
<thead>  
<tr>  
<td>  
ID </td>  
<td>  
Name </td>  
<td>  
Email </td>  
<td>  
Gender </td>  
<td>  
Address </td>  
<td>Contact</td>
</tr>  
</thead>  
<tbody>  
@foreach($users as $user)  
        <tr border="none">  
            <td>{{$user->userid}}</td>  
            <td>{{$user->name}}</td>  
            <td>{{$user->email}}</td>  
            <td>{{$user->address}}</td>  
            <td>{{$user->gender}}</td>  
            <td>{{$user->contact}}</td> 
            <td>
            <form action="{{ url('admin/destroy').'/'.$user->userid}}" method="POST">  
                  {{ csrf_field() }} 
                  <button class="btn btn-danger" type="submit">Delete</button>  
                </form>  
               </td>
             <td>
             	<form action="{{ url('admin/edit').'/'.$user->userid}}" method="POST">  
                  {{ csrf_field() }}
                  <button class="btn btn-danger" type="submit">Edit</button>  
                </form>  
</td>  
             </td>
</td>
         </tr>  
@endforeach  
</tbody>  
</table>
@endsection