<!doctype html>
<html>
<head>
   <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="Saquib" content="Blade">
    <title>Application Form</title>
    <!-- load bootstrap from a cdn -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style type="text/css">
        .main-box{
            padding:20px;
            margin-top:0px;
            background: #fff;
            margin-left:150px;
        }
    </style>
</head>
<body>
<div class="container">
   <header class="row">
    <div class="col-md-8 main-box">
       Application
   </div>
   </header>
   <div id="main" class="row">
        <div>
            @yield('error')
        </div>
        <div>
            @yield('content')
        </div>
   </div>
</div>
</body>
</html>